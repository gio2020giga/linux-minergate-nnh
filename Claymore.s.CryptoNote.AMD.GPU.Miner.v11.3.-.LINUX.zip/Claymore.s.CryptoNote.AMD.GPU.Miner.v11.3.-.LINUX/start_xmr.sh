./nsgpucnminer -xpool stratum+ssl://xmr-eu1.nanopool.org:14433 -xwal YOUR_XMR_ADDRESS.YOUR_PAYMENT_ID.YOUR_WORKER/YOUR_EMAIL -xpsw x
